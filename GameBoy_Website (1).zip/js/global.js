
document.getElementById('global-header').innerHTML = '<nav><a href="index.html">Home</a> | <a href="about.html">About</a> | <a href="product.html">Product</a> | <a href="contact.html">Contact</a></nav>';
document.getElementById('global-footer').innerHTML = '<p>&copy; 2024 Game Boy Fansite</p>';
